% banana_draw.m
% ���ƺ���ͼ��
x=[-1.5:0.125:1.5];
y=[-0.6:0.125:2.8];
[X,Y]=meshgrid(x,y);
Z=100*(Y-X.*X).^2+(1-X).^2;
mesh(X,Y,Z);
hidden off;
title('function of banana')
hold on;
plot3(1,1,1,'k.','markersize',30);
hold off;