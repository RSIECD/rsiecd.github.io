%fminunc
x0=[-0.9,2];
options=optimset('Display','iter','tolfun',1e-18,'GradObj','on');
[x,fval,exitflag,output,grad]=fminunc(@banana,x0,options) %flag=2 Change in x was smaller than the TolX tolerance
%fminsearch
options=optimset('TolFun',1e-8,'TolX',1e-8);
[xmin,value,flag,output]=fminsearch(@banana,[-1.9,2],options)  %flag=1,Magnitude of gradient smaller than the TolFun tolerance


%Example 1
%The Rosenbrock banana function is a classic test example for multidimensional minimization:
%The minimum is at (1,1) and has the value 0. The traditional starting point is (-1.2,1). The anonymous function shown here defines the function and returns a function handle called banana:
banana = @(x)100*(x(2)-x(1)^2)^2+(1-x(1))^2;


%Example 1
%Pass the function handle to fminsearch:
[x,fval] = fminsearch(banana,[-1.2, 1])
%This indicates that the minimizer was found to at least four decimal places with a value near zero.
%Example 2
%If fun is parameterized, you can use anonymous functions to capture the problem-dependent parameters. For example, suppose you want to minimize the objective function myfun defined by the following function file:
function f = myfun(x,a)
f = x(1)^2 + a*x(2)^2;
%Note that myfun has an extra parameter a, so you cannot pass it directly to fminsearch. To optimize for a specific value of a, such as a = 1.5.
%1.Assign the value to a. 
a = 1.5; % define parameter first
%2.Call fminsearch with a one-argument anonymous function that captures that value of a and calls myfun with two arguments:
x = fminsearch(@(x) myfun(x,a),[0,1])
%Example 3
%You can modify the first example by adding a parameter a to the second term of the banana function:
%This changes the location of the minimum to the point [a,a^2]. To minimize this function for a specific value of a, for example a = sqrt(2), create a one-argument anonymous function that captures the value of a.
a = sqrt(2);
banana = @(x)100*(x(2)-x(1)^2)^2+(a-x(1))^2;
%Then the statement 
[x,fval] = fminsearch(banana, [-1.2, 1], ...
   optimset('TolX',1e-8));
%seeks the minimum [sqrt(2), 2] to an accuracy higher than the default on x.
