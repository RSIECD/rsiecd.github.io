% vdpol_events.m
% ��Ӧ�¼�����
mu=2;
options=odeset('Events',@vdpolevents);
[t,y,te,ye]=ode45(@vdpol,tspan,yo,options,mu);
plot(t,y,te,ye(:,2),'o');
title('Van der Pol resutls for |y(2)=1.5|')
legend('x','dx/dt');