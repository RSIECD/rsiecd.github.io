%Define the sample points, x, and corresponding sample values, v.
x = 0:pi/4:2*pi;
v = sin(x);
%Define the sample points, x, and corresponding sample values, v.
xq = 0:pi/16:2*pi;
%Define the sample points, x, and corresponding sample values, v.
figure
vq1 = interp1(x,v,xq);
plot(x,v,'o',xq,vq1,'r*');
xlim([0 2*pi]); %Set or query x-axis limits
grid on
title('(Default) Linear Interpolation');
%Now evaluate v at the same points using the 'spline' method.
figure
vq2 = interp1(x,v,xq,'spline');
plot(x,v,'o',xq,vq2);
xlim([0 2*pi]);
grid on
title('Spline Interpolation');

%Define the sample points, x, and corresponding sample values, v.
x = [-3 -2 -1 0 1 2 3];
v = 3*x.^2;
%Specify the query points, xq, that extend beyond the domain of x.
xq = [-4 -2.5 -0.5 0.5 2.5 4];
%Now evaluate v at xq using the 'pchip' method and assign any values outside the domain of x to the value, 27.
vq = interp1(x,v,xq,'pchip',27)
figure
vq = interp1(x,v,xq,'spline')
plot(x,v,'o',xq,vq);
xlim([-5 5]);
grid on
title('Pchip Interpolation');

%interpolate Multiple Sets of Data in One Pass
%Define the sample points.
x = (-5:5)';
%Sample three different parabolic functions at the points defined in x.
v1 = x.^2;
v2 = 2*x.^2 + 2;
v3 = 3*x.^2 + 4;
%Create matrix v, whose columns are the vectors, v1, v2, and v3.
v = [v1 v2 v3];
%Define a set of query points, xq, to be a finer sampling over the range of x.
xq = -5:0.1:5;
%Evaluate all three functions at xq and plot the results.
vq1 = interp1(x,v,xq,'pchip');
vq2 = interp1(x,v,xq);
figure
plot(x,v,'o',xq,vq,'r*');
set(gca,'XTick',-5:5);
vq=vq1-vq2
