function f=optfun(x)
f=-x(1)*x(2)*x(3);