function dydt=massode(t,y,m1,m2,L,g)
% ΢�ַ��̾���
dydt=[y(2);
    m2*L*y(6)^2*cos(y(5));
    y(4);
    m2*L*y(6)^2*sin(y(5))-(m1+m2)*g;
    y(6);
    -g*L*cos(y(5))];