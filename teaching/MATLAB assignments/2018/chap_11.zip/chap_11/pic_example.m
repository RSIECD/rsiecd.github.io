% pic_example.m
x=0:pi/12:2*pi;
plot(sin(x),cos(x),'color','blue','linewidth',5,'marker','d');
axis square;
PS.Color=[0.7 0.7 0];
PS.LineWidth=2;
line(sin(7*x),cos(7*x),PS);