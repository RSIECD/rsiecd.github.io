% �ƶ������λ�÷�Χ[-1 1]
function movecamera(dist) %dist in the range [-1 1]
set(gca,'CameraViewAngleMode','manual')
newcp=cpos - dist * (cpos - ctarg);
set(gca,'CameraPosition',newcp)
function out = cpos
out=get(gca,'CameraPosition');
function out = ctarg
out=get(gca,'CameraTarget');