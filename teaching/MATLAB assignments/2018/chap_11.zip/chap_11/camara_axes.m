% camara_axes.m
surf(peaks); 
axis vis3d
xp=linspace(-150,15,50);
xt=linspace(0,10,50);
for i=1:50
     campos([-xp(i),-xp(i),-xp(i)]);
     camtarget([xt(i),30,0])
     drawnow
end
