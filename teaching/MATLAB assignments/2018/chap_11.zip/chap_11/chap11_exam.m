excelDates = xlsread('test.xls')
xlsfinfo('test.xls')
values = {1, 2, 3 ; 4, 5, 'x' ; 7, 8, 9};
headers = {'First', 'Second', 'Third'};
xlswrite('myExample.xlsx', [headers; values]);

[status,sheets,xlFormat] = xlsfinfo('myExample.xlsx')
imfinfo
A = importdata('ngc6543a.jpg');
image(A);
type exp.txt
fid=fopen('exp.txt')  
a1=fscanf(fid,'%s')   %���ַ�����ʽ��ȡ�ĸ�����  
fclose(fid) 

filename = 'csvlist.dat';
M = csvread(filename)

x = 1:1:5;
y = [x;rand(1,5)];
fileID = fopen('nums2.txt','w');
fprintf(fileID,'%d %4.4f\n',y);
fclose(fileID);

fileID = fopen('nums2.txt','r');
formatSpec = '%d %f';
sizeA = [2 Inf];
A = fscanf(fileID,formatSpec,sizeA)
fclose(fileID);
A=A'


str = '78��C 72��C 64��C 66��C 49��C';
fileID = fopen('temperature.dat','w');
fprintf(fileID,'%s',str);
fclose(fileID);

fileID = fopen('temperature.dat','r');
degrees = char(176);
[A,count] = fscanf(fileID, ['%d' degrees 'C'])
fclose(fileID);

x = 0:.1:1;
A = [x; exp(x)];

fileID = fopen('exp2.txt','w');
fprintf(fileID,'%6s %12s\n','x','exp(x)');
fprintf(fileID,'%6.2f %12.8f\n',A);
fclose(fileID);

textscan

fileID = fopen('nine.bin','w');
fwrite(fileID,[1:9]);
fclose(fileID);

fileID = fopen('nine.bin');
A = fread(fileID)
fclose(fileID);

fid = fopen('magic5.bin', 'w');
fwrite(fid, magic(5), 'integer*4');
fclose(fid);
fileID = fopen('magic5.bin');
A = fread(fileID)
fclose(fileID);

[pathstr,name,ext]=fileparts('C:\Users\cui\Documents\MATLAB\exp.txt')
filesep
f = fullfile('myfolder','mysubfolder','myfile.m')