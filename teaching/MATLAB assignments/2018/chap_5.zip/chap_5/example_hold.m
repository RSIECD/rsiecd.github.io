% example_hold.m
% hold�����ʹ��
x=linspace(0,2*pi,100);
y=sin(2*x);
z=cos(3*x);
plot(x,y);
hold on;
ishold;
plot(x,z,'m*-');
hold off;
ishold;
grid on;
axis square;
legend('y=sin(2*x)','z=cos(3*x)');
title('hold examples');

