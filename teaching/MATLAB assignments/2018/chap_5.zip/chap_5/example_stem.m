% example_stem.m
x=0:30;
y=[exp(-.07*x).*cos(x);exp(.05*x).*cos(x)]';
h=stem(x,y);
set(h(1),'MarkerFaceColor','blue')
set(h(2),'MarkerFaceColor','red','Marker','square')
hold on;
plot(x,y);
hold off;
title('figure: stem example')
legend('exp(-0.07*x).*cos(x)','exp(0.05*x).*cos(x)');