% example_contour.m
% contour��������
Z=peaks;
[C,h]=contour(interp2(Z,4));
text_handle=clabel(C,h);
set(text_handle,'BackgroundColor',[1 1 .6],'Edgecolor',[.7 .7 .7])
title('contour of peaks');
