% example_bar.m
% ����ֱ��ͼ������ͼ
x=-2.9:0.2:2.9;
y=exp(-x.*x);
% figure1: 2d bar chart
subplot(2,2,1);
bar(x,y);
title('figure1: 2d bar chart');
% figure2: 3d bar chart
subplot(2,2,2);
bar3(x,y,2,'r');
title('figure2: 3d bar chart');
% figure3: stair chart
subplot(2,2,3);
stairs(x,y);
title('figure3: stair chart');
% figure4: barh chart
subplot(2,2,4);
barh(x,y);
title('figure4: barh chart');