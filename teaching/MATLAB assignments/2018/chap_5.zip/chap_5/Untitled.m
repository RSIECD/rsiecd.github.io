
x =0:pi/10:2*pi;
t = exp(-x.^2);
yy=exp(-x.^2).*sin(x);

e = abs(yy-t);

figure
errorbar(x,t,e)