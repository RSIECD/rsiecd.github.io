% example_contour_color.m
% ��ɫ���ĵ�ֵ��ͼ
[x,y,z]=peaks(30);
% ͼ1��pcolor
subplot(1,2,1)
pcolor(x,y,z);
shading interp;
axis square;
title('figure1: pcolor');
% ͼ2��contourf
subplot(1,2,2)
contourf(x,y,z);
axis square;
title('figure2: contourf');
