% example_plot3.m
% ʹ�ú���plot3������ά����
t=0:pi/50:10*pi;
plot3(sin(t),cos(t),t,'r*-')
xlabel('sin(t)')
ylabel('cos(t)')
zlabel('t')
title('figure1: helix')
grid on
axis square
% ���ƶ�������
figure(2);
x=linspace(0,3*pi,200);
z1=sin(x);
z2=sin(2*x);
z3=sin(3*x);
y1=zeros(size(x));
y2=ones(size(x));
y3=y2*2;
plot3(x,y1,z1,'r*',x,y2,z2,'bp',x,y3,z3,'mx');
grid on;
xlabel('x-axis')
ylabel('y-axis')
zlabel('z-axis')
title('figure2: sin(x),sin(2x),sin(3x)');
grid on;
axis square;