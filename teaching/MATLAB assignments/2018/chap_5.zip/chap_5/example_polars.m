% example_polars.m
% ���Ƽ�����ͼ��
t=linspace(0,2*pi);
r=sin(2*t).*cos(2*t);
% figure a: polar
subplot(2,2,1);
polar(t,r);
title('figure a: polar')
% figure b: compass
subplot(2,2,2);
z=eig(randn(20));
compass(z);
title('figure b: compass');
% figure c: feather
subplot(2,2,3);
feather(z);
title('figure c: feather');
% figure d: rose
subplot(2,2,4);
v=randn(1000,1);
rose(v);
title('figure d: rose');
