%mesh ����peaks������
[x,y,z]=peaks(30);
mesh(x,y,z);
xlabel('x-axis');
ylabel('y-axis');
zlabel('z-axis');
title('mesh of peaks');
colormap(hsv)
meshc(x,y,z);
meshz(x,y,z);
waterfall(x,y,z);