% example_isosurfaces.m
% ��ͬ��������µĽ��
% ���ɻ���ͼ������
[x,y,z,v]=flow(13);
% ͨ��isosurface����Ѱ�ҵ�ֵ��
fv=isosurface(x,y,z,v,-2);
% figure1��ԭʼͼ��;
subplot(2,2,1);
p=patch(fv);
set(p,'facecolor',[.5 .5 .5],'edgecolor','black');
view(-45,30);axis equal tight;grid on;
title('figure a: original');
% figure2��reduce volume;
subplot(2,2,2);
[xr,yr,zr,vr]=reducevolume(x,y,z,v,[3,2,2]);
fvr=isosurface(xr,yr,zr,vr,-2);
p=patch(fvr);
np=size(get(p,'faces'),1);
set(p,'facecolor',[.5 .5 .5],'edgecolor','black');
view(-45,30);axis equal tight;grid on;
title('figure b: reduce volume');
% figure3��reduce patch;
subplot(2,2,3);
p=patch(fv);
set(p,'facecolor',[.5 .5 .5],'edgecolor','black');
view(-45,30);axis equal tight;grid on;
reducepatch(p,0.15);
np=size(get(p,'faces'),1);
title('figure c: reduce patch');
% figure4��smooth3;
subplot(2,2,4);
p=patch(fv,'facecolor','blue','edgecolor','none');
view(-45,30);axis equal tight;grid on;
title('figure c: reduce patch');
