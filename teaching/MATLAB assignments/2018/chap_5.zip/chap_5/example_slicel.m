% example_slicel.m
% slice��Ƭ����ʾ��
[x,y,z,v]=flow;  %produces a 50-by-25-by-25 array.
x1=min(min(min(x)));
x2=max(max(max(x)));
sx=linspace(x1+1.5,x2,4);
slice(x,y,z,v,sx,0,0);
shading interp;
colorbar
