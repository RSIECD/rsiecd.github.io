% factorization_cholinc.m
% ����ȫCholesky�ֽ�ʾ��
S = sparse([ 1     0     3     0;
             0    25     0    30;
             3     0     9     0;
             0    30     0   661 ]);
disp('��ȫcholesky�ֽ⣺')
[R,p] = cholinc(S,'0')
Rfull=full(R)
Srfull=Rfull'*Rfull
disp('����ȫcholesky�ֽ⣺')
Rinf = cholinc(S,'inf')
Rinf_full=full(Rinf)
Srinf_full=Rinf_full'*Rinf_full