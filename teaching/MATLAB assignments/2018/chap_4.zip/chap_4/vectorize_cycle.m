% vectorize_cycle.m
% ѭ���ṹ��˷�
for i=1:100
    square(i)=i^2;
    cube(i)=i^3;
    quartic(i)=i^4;
end
disp('       square       cube        quartic')
result=[square',cube',quartic']
disp('       square       cube        quartic')