function [xh,yh]=drawheart(varargin)
% ����������������仯��ʾ��
% �жϿɱ�������������ĸ���
error(nargchk(0,3,nargin));
nin=nargin;
if nin==0
    cx1=0;
    cy1=0;
    r=1.0;
elseif nin==1
    cx1=0;
    cy1=0;
    r=varargin{1};
elseif nin==2
    cx1=0;
    cy1=varargin{1};
    r=varargin{2};   
else
    cx1=varargin{1};
    cy1=varargin{2};
    r=varargin{3};
end

if nargout==0
    flag=1;
else
    flag=0;
end
%  ��������
theta=linspace(0,2*pi,100);
x0=r*cos(theta);
y0=r*sin(theta);
x1=x0+cx1;
y1=y0+cy1;
cx2=2*x0+cx1;
cy2=2*y0+cy1;
x3=x0.*cos(theta)-y0.*sin(theta);
y3=x0.*sin(theta)+y0.*cos(theta);
for k=1:100
    x2(k,:)=cx2(k)+x0;
    y2(k,:)=cy2(k)+y0;
    xx(k)=cx2(k)+x3(k);
    yy(k)=cy2(k)+y3(k);
end
xh=xx;
yh=yy;
if flag
    plot(cx1,cy1,'bp','Markersize',6);
    hold on;
    %plot(x1,y1);
    axis([cx1-3.2*r,cx1+3.2*r,cy1-3.2*r,cy1+3.2*r]);
    axis manual;
    hold on;
    daspect([1 1 1]);
    set(gcf,'doublebuffer','on');
    for k=1:100
        plot(x2(k,:),y2(k,:),'g',xx(k),yy(k),'r*');
        grid on;
        pause(0.05);
    end
end